#!/bin/bash
# 安全なデプロイスクリプト

# serverless v3を使用
SERVERLESS_VERSION="3.40.0"

# serverless cliをローカルにインストール
if [ ! -f "./node_modules/.bin/serverless" ]; then
    echo "Installing serverless locally..."
    npm install --save-dev serverless@${SERVERLESS_VERSION}
fi

# デプロイ実行
echo "Deploying with serverless v${SERVERLESS_VERSION}..."
./node_modules/.bin/serverless deploy --stage dev